const fs =require('fs');

var file = 'product.json'


function loadData_Synchronous() 
{
    console.log("Reading from products");
    var customers = fs.readFileSync(file, {encoding: 'utf8'});
    console.log("Completed Reading from products");
    return customers;
}

function writeData_Synchronous(data) {
    console.log("Taking Backup from products");

    try {
        fs.writeFileSync("backup_products.txt", data, { encoding: "utf8" });
        console.log("File written successfully");

        fs.chmodSync("backup_products.txt", 0o444);
        console.log("Permissions changed to read-only");
    } catch (err) {
        console.error("Error during backup:", err);
    }
}


function loadData_user1(){
    console.log("User1 Reading");
    var customers = fs.readFileSync('backup_products.txt', {encoding: 'utf8'});
    console.log(customers);
}


function loadData_user2() {
    console.log("User2 Reading");
    fs.readFile('backup_products.txt', { encoding: 'utf8' }, (err, data) => {
        if (err) {
            console.error("Error reading file in User2:", err);
            return;
        }
        console.log(data);
    });
}


function loadData_user3() {
    console.log("User3 Reading");
    fs.readFile('backup_products.txt', { encoding: 'utf8' }, (err, data) => {
        if (err) {
            console.error("Error reading file in User3:", err);
            return;
        }
        console.log(data);
    });
}


function delete_backup()
{
   console.log("Going to delete an backup file");
   fs.unlink('backup_products.txt', function(err) {
   if (err) {
      return console.error(err);
   }
   console.log("File deleted successfully!");
});
}

function loadData()
{
    console.log('we are starting with loadData() method....');
    var customers = fs.readFileSync('product.json', {encoding: 'utf8'}); 
    return JSON.parse(customers.toString())
}

function writeProduct(id,name,category,price,stock,rating){
    console.log('we are starting with writeData() method....');
    var products = loadData();  
    products.push({
    "id": id,
    "name": name,
    "category": category,
    "price": price,
    "stock": stock,
    "rating": rating
    });
    fs.writeFileSync(file,JSON.stringify(products));
}

module.exports={
    load: loadData_Synchronous,
    write: writeData_Synchronous,
    user1:loadData_user1,
    user2:loadData_user2,
    user3:loadData_user3,
    delete:delete_backup,
    product:writeProduct
}





