const users1 = [
    {
      id: 1,
      name: "Sandeep",
      email: "sandeep@gmail.com"
    },
    {
      id: 2,
      name: "Smith",
      email: "smith@gmail.com"
    },
    {
      id: 3,
      name: "Arpit",
      email: "arpit@gmail.com"
    },
    {
      id: 4,
      name: "Manu",
      email: "manu@gmail.com"
    }
  ];
  
  module.exports = users1;