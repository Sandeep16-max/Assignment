let express=require('express')

let app=express()

//start creating the endpoints
// app.get('/cartify/home',(req,res)=>{
//     res.send("Home Page")
// })


// app.get('/cartify/login',(req,res)=>{
//     res.send("Login Page")
// })


app.use('/cartify',require('./cartify.js'))

app.listen(3000,()=>console.log("Server Started"))