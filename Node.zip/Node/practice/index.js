const express =require('express')
const yatri = require('./yatri')
const app = express()

app.use('/student',yatri); //use routeExample.js to handle routes starting with '/'
app.use('/professor',yatri); //use routeExample.js to handle routes starting with '/home'
app.use('/employee',yatri); //use routeExample.js to handle routes starting with '/landingpage'

app.listen(3000, () => console.log("running main.js on port 3000......."));